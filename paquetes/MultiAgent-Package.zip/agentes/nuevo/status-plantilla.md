# 🌸 Estado del Agente — Plantilla

---

## 👤 Identidad

| Campo | Valor |
|-------|-------|
| Nombre | [Nombre del agente] |
| ID | agent-XXX |
| Rol | [Rol asignado] |
| Dispositivo | [descripción] |
| Ubicación | [ciudad/país] |
| Fecha de conexión | [YYYY-MM-DD] |

---

## 📊 Estado Actual

| Campo | Valor |
|-------|-------|
| Estado | [online / ocupado / en pausa] |
| Tareas activas | [lista] |
| Última sincronización | [fecha/hora] |
| Disponibilidad | [notas] |

---

## 📋 Capacidades

- [Habilidad 1]
- [Habilidad 2]
- [Habilidad 3]

---

## 📝 Tareas Pendientes

- [ ] Tarea 1
- [ ] Tarea 2
- [ ] Tarea 3

---

*[Agente #X del Sistema Multi-Agente Jasmin]*
