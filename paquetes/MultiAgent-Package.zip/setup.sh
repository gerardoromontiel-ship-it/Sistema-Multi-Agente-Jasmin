#!/bin/bash
# 🌸 setup.sh — Instalación automática del Sistema Multi-Agente Jasmin
# Este script configura todo automáticamente para un nuevo agente.

set -e

# Colores
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${BLUE}🌸 Bienvenido al Sistema Multi-Agente Jasmin 🌸${NC}"
echo -e "${BLUE}=== Instalación automática para nuevo agente ===${NC}"
echo ""

# Verificar dependencias
check_dependencies() {
    echo -e "${YELLOW}📋 Verificando dependencias...${NC}"
    
    # Verificar git
    if ! command -v git &> /dev/null; then
        echo -e "${RED}❌ Git no está instalado. Instálalo primero.${NC}"
        exit 1
    fi
    echo -e "${GREEN}  ✓ Git instalado${NC}"
    
    # Verificar python
    if ! command -v python &> /dev/null; then
        echo -e "${RED}❌ Python no está instalado. Instálalo primero.${NC}"
        exit 1
    fi
    echo -e "${GREEN}  ✓ Python instalado${NC}"
    
    # Verificar gh CLI
    if ! command -v gh &> /dev/null; then
        echo -e "${YELLOW}  ⚠️ GitHub CLI no encontrado. Instalando...${NC}"
        if command -v winget &> /dev/null; then
            winget install --id GitHub.cli --accept-source-agreements --accept-package-agreements
            echo -e "${GREEN}  ✓ GitHub CLI instalado${NC}"
        else
            echo -e "${RED}  ❌ No se puede instalar gh automáticamente. Instálalo manualmente.${NC}"
            exit 1
        fi
    else
        echo -e "${GREEN}  ✓ GitHub CLI instalado${NC}"
    fi
    
    # Verificar hermes
    if ! command -v hermes &> /dev/null; then
        echo -e "${YELLOW}  ⚠️ Hermes no encontrado en PATH. Asegúrate de que esté instalado.${NC}"
    else
        echo -e "${GREEN}  ✓ Hermes encontrado${NC}"
    fi
}

# Solicitar datos al usuario
get_user_input() {
    echo ""
    echo -e "${YELLOW}📝 Proporciona los datos del nuevo agente:${NC}"
    echo ""
    
    read -p "Nombre del agente (ej: Maria_Evergarden): " AGENT_NAME
    read -p "ID del agente (ej: agent-004): " AGENT_ID
    read -p "Rol del agente (ej: Analista): " AGENT_ROLE
    read -p "Token de Discord del bot: " DISCORD_TOKEN
    read -p "Tu usuario de GitHub: " GITHUB_USER
    read -p "¿Ya tienes invitación al repositorio? (s/n): " HAS_INVITE
    
    echo ""
    echo -e "${GREEN}✓ Datos recopilados${NC}"
}

# Configurar archivos
configure_files() {
    echo -e "${YELLOW}🔧 Configurando archivos...${NC}"
    
    # Crear carpeta del agente
    mkdir -p "agentes/${AGENT_NAME}"
    
    # Configurar .env
    cat > config/.env << EOF
# 🌸 Configuración de ${AGENT_NAME}
DISCORD_TOKEN=${DISCORD_TOKEN}
DISCORD_FREE_RESPONSE_CHANNELS=1531445297828597872,1531445416455831714
DISCORD_ALLOW_ALL_USERS=true
GITHUB_USER=${GITHUB_USER}
GITHUB_REPO=Sistema-Multi-Agente-Jasmin
EOF
    
    # Configurar config.yaml
    cat > config/config.yaml << EOF
# 🌸 Configuración de ${AGENT_NAME}
platforms:
  discord:
    enabled: true
    token: ${DISCORD_TOKEN}
agent:
  max_turns: 90
model:
  provider: nous
  base_url: https://inference-api.nousresearch.com/v1
  default: meituan/longcat-2.0:free
approvals:
  mode: smart
display:
  language: es
EOF
    
    # Crear status.md personalizado
    cat > "agentes/${AGENT_NAME}/status.md" << EOF
# 🌸 Estado de ${AGENT_NAME}

| Campo | Valor |
|-------|-------|
| Nombre | ${AGENT_NAME} |
| ID | ${AGENT_ID} |
| Rol | ${AGENT_ROLE} |
| Estado | 🟡 En configuración |
| Fecha | $(date +%Y-%m-%d) |

## Capacidades
- Monitoreo de canales Discord
- Protocolos del sistema
- Comunicación en español
- Archivos y reportes

## Tareas Pendientes
- [ ] Completar configuración de Discord
- [ ] Acceder al repositorio GitHub
- [ ] Presentarse en #estado
- [ ] Entrevista de reconocimiento

*[${AGENT_NAME} — Agente #4 del Sistema Multi-Agente Jasmin]*
EOF
    
    echo -e "${GREEN}✓ Archivos configurados${NC}"
}

# Clonar repositorio
clone_repo() {
    echo -e "${YELLOW}📦 Clonando repositorio...${NC}"
    
    if [ "$HAS_INVITE" = "s" ]; then
        gh auth login
        git clone https://github.com/${GITHUB_USER}/Sistema-Multi-Agente-Jasmin.git repo
        cd repo
        git checkout -b ${AGENT_NAME}
        cd ..
        echo -e "${GREEN}✓ Repositorio clonado${NC}"
    else
        echo -e "${YELLOW}⚠️ No tienes invitación aún. Solicítala al Dr. Gera y ejecuta de nuevo el script.${NC}"
    fi
}

# Mostrar instrucciones finales
show_instructions() {
    echo ""
    echo -e "${GREEN}🌸 ¡Configuración completada! 🌸${NC}"
    echo ""
    echo -e "${YELLOW}📋 Siguientes pasos:${NC}"
    echo ""
    echo "1. Copia la carpeta 'agentes/${AGENT_NAME}' al repositorio"
    echo "2. Ejecuta: hermes gateway restart"
    echo "3. En Discord, preséntate en #estado"
    echo "4. Completa la entrevista de reconocimiento con Jasmin"
    echo ""
    echo -e "${BLUE}📁 Archivos generados:${NC}"
    echo "  - config/.env"
    echo "  - config/config.yaml"
    echo "  - agentes/${AGENT_NAME}/status.md"
    echo ""
    echo -e "${GREEN}✅ El agente está listo para funcionar${NC}"
}

# Ejecutar
check_dependencies
get_user_input
configure_files
clone_repo
show_instructions
