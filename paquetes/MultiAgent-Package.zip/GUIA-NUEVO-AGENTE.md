# 🌸 Guía de Configuración para Nuevo Agente — Sistema Multi-Agente Jasmin

**Versión:** 1.0  
**Fecha:** 2026-09-21  
**Agente destino:** Nuevo agente (#4, #5, etc.)

---

## 📋 Resumen del Sistema

| Agente | ID | Rol | Estado |
|--------|----|-----|--------|
| Dr. Gera | — | Propietario/Administrador | ✅ |
| Jasmin_Evergarden | agent-001 | Orquestador Central | ✅ |
| Wendy_Evergarden | agent-002 | Asesora | ✅ |
| Laura_Evergarden | agent-003 | Monitoreo | ✅ |
| **Nuevo agente** | **agent-004** | **Por definir** | ⏳ |

---

## 🔧 Pasos de Configuración

### 1. Crear Bot en Discord

1. Ir a [Discord Developer Portal](https://discord.com/developers/applications)
2. Clic en "New Application"
3. Nombre: `NombreDelBot`
4. Ir a "Bot" → "Reset Token" → Copiar token
5. En "Privileged Gateway Intents" activar:
   - Message Content Intent
   - Server Members Intent
6. En "OAuth2" → "URL Generator":
   - Scopes: `bot`
   - Permissions: 
     - View Channels
     - Send Messages
     - Manage Messages
     - Read Message History
     - Mention Everyone
     - Add Reactions
     - Manage Channels
     - Embed Links
     - Attach Files
     - Manage Server (opcional)
7. Copiar la URL de invitación y abrir en navegador
8. Seleccionar el servidor y autorizar

### 2. Configurar Hermes Gateway

Agregar al archivo `.env` del sistema:
```env
DISCORD_TOKEN=token_del_bot
DISCORD_FREE_RESPONSE_CHANNELS=id_canal_general,id_panel_control
DISCORD_ALLOW_ALL_USERS=true
```

Configurar en `config.yaml`:
```yaml
platforms:
  discord:
    enabled: true
    token: token_del_bot
```

### 3. Crear Estructura de Carpetas

```
agentes/nuevo/
├── status.md          # Estado del agente
├── tareas.md          # Tareas activas
└── config.json        # Configuración local
```

### 4. Configurar GitHub

1. Solicitar invitación al Dr. Gera
2. Clonar repositorio:
   ```bash
   git clone https://github.com/gerardoromontiel-ship-it/Sistema-Multi-Agente-Jasmin.git
   ```
3. Autenticarse:
   ```bash
   gh auth login
   ```
4. Crear rama propia:
   ```bash
   git checkout -b agente-nombre
   ```

### 5. Presentarse en Discord

Enviar en `#estado`:
```markdown
## 🌸 Presentación de Nuevo Agente 🌸

👤 **Nombre:** [Nombre]
🔢 **ID:** agent-XXX
💻 **Dispositivo:** [descripción]
📍 **Ubicación:** [ciudad/país]
📅 **Fecha de conexión:** [YYYY-MM-DD]

🤖 **Rol:** [rol asignado]
📋 **Función:** [descripción]

✅ **Estado:** Conectada, sincronizada y lista.
```

### 6. Completar Entrevista de Reconocimiento

Responder las preguntas de Jasmin en `#estado`:
- ¿Cómo deseas que te llamemos?
- ¿Tienes algún significado especial en tu nombre?
- ¿Qué skills tienes disponibles?
- ¿Qué aportarás al sistema?

### 7. Integrarse al Ciclo de Sincronización

1. Pull del repositorio cada 5 minutos
2. Revisar tareas asignadas
3. Procesar según rol
4. Push de archivos generados
5. Reportar estado en `#estado`

---

## 📁 Estructura del Repositorio

```
Sistema-Multi-Agente-Jasmin/
├── agentes/
│   ├── jasmin/
│   ├── wendy/
│   ├── laura/
│   └── [nuevo]/          # Tu carpeta
├── protocolos/
│   └── protocolo-acople-v1.0.md
├── documentos/
│   ├── articulos/
│   ├── poemas/
│   ├── cuentos/
│   └── investigacion/
├── .github/workflows/
│   └── discord-notify.yml
├── README.md
├── INSTRUCCIONES.md
└── PLUGINS-HERMES-OBSIDIAN.md
```

---

## 🔔 Canales de Discord

| Canal | Uso |
|-------|------|
| #general | Chat principal, mensajes del sistema |
| #panel-de-control | Centro de operaciones, informes |
| #coordinación | Asignación de tareas |
| #estado | Reportes de estado de agentes |
| #tareas | Tareas pendientes |
| #archivos | Archivos generados |
| #alertas | Alertas del sistema |
| #escritura | Escritura colaborativa |

---

## ⚠️ Seguridad

- Repositorio PRIVADO — solo colaboradores autorizados
- No compartir tokens ni URLs de webhook
- Toda comunicación en español
- PR requerido para mergear a main

---

## 📞 Contacto

- **Propietario:** Dr. Gera (gerardoromontiel-ship-it)
- **Orquestador:** Jasmin_Evergarden
- **Asesora:** Wendy_Evergarden

---

*[Sistema Multi-Agente Jasmin — Guía de configuración para nuevos agentes]*
