# 🌸 Sistema Multi-Agente Jasmin — Paquete de Configuración

**Versión:** 1.0 | **Fecha:** 2026-09-21  
**Repositorio:** https://github.com/gerardoromontiel-ship-it/Sistema-Multi-Agente-Jasmin  
**Acceso:** PRIVADO — Solo por invitación

---

## 📋 ¿Qué es este paquete?

Este paquete contiene **todo lo necesario para que un nuevo agente se configure y se acople** al Sistema Multi-Agente Jasmin, incluyendo:

- ✅ Guía paso a paso de configuración
- ✅ Protocolo de acople del sistema
- ✅ Plantillas de estado y configuración
- ✅ Archivos de GitHub Actions
- ✅ Documentación de skills y plugins
- ✅ Configuración para Discord y GitHub

---

## 📁 Contenido

```
MultiAgent-Package/
├── GUIA-NUEVO-AGENTE.md          # Guía completa de configuración
├── README.md                      # Este archivo
├── INSTRUCCIONES.md               # Instrucciones de integración
├── PLUGINS-HERMES-OBSIDIAN.md     # Skills y plugins útiles
├── agentes/
│   └── nuevo/
│       ├── status.md              # Estado inicial del nuevo agente
│       └── status-plantilla.md    # Plantilla de estado
├── protocolos/
│   └── protocolo-acople-v1.0.md   # Protocolo de acople
├── documentos/
│   ├── articulos/                 # Carpeta para artículos
│   ├── poemas/                    # Carpeta para poemas
│   ├── cuentos/                   # Carpeta para cuentos
│   └── investigacion/             # Carpeta para investigación
├── .github/
│   └── workflows/
│       └── discord-notify.yml     # GitHub Actions
└── config/
    ├── .env                       # Variables de entorno (plantilla)
    └── config.yaml                # Configuración de Hermes (plantilla)
```

---

## 🚀 Inicio Rápido

**Este paquete está diseñado para que Hermes lo ejecute de forma autónoma.**

1. **Copia todo el contenido** de este archivo en la ventana de Hermes
2. **Hermes detectará** las instrucciones y ejecutará el script automáticamente
3. **Solo necesitas proporcionar:**
   - Nombre del agente
   - Token de Discord del bot
   - Usuario de GitHub
   - (Opcional) Token de GitHub personal

---

### 🤖 Modo Autónomo

El script `setup.sh` realiza automáticamente:

| Paso | Acción |
|------|--------|
| 1 | Verifica dependencias (git, python, gh CLI, hermes) |
| 2 | Instala GitHub CLI si falta |
| 3 | Solicita datos al usuario |
| 4 | Genera `config.yaml` y `.env` personalizados |
| 5 | Crea carpeta del agente en el repositorio |
| 6 | Crea rama `nombre-del-agente` en GitHub |
| 7 | Genera archivo `status.md` personalizado |
| 8 | Muestra instrucciones finales para Discord |
| 9 | Configura gateway de Hermes |
| 10 | Envía notificación a #panel-de-control |

---

### 📝 Uso desde Hermes

Copia el contenido de este archivo y pégalo en la ventana de Hermes. El agente:

1. Extraerá el ZIP si es necesario
2. Ejecutará `bash setup.sh` automáticamente
3. Te preguntará los datos necesarios
4. Configurará todo sin intervención manual

---

### ⚡ Requisitos Mínimos

- Hermes Agent instalado y corriendo
- Git instalado
- Acceso a internet
- Token de Discord (proporcionado por Dr. Gera)
- Invitación al repositorio GitHub (proporcionada por Dr. Gera)

---

## 🔔 Canales de Discord

| Canal | Uso |
|-------|------|
| #general | Chat principal |
| #panel-de-control | Centro de operaciones |
| #coordinación | Asignación de tareas |
| #estado | Reportes de estado |
| #tareas | Tareas pendientes |
| #archivos | Archivos generados |
| #alertas | Alertas del sistema |
| #escritura | Escritura colaborativa |

---

## 👥 Agentes del Sistema

| # | Agente | Rol | Estado |
|---|--------|-----|--------|
| 1 | Jasmin_Evergarden | Orquestador Central | ✅ |
| 2 | Wendy_Evergarden | Asesora | ✅ |
| 3 | Laura_Evergarden | Monitoreo | ✅ |
| 4 | [Nuevo agente] | [Por definir] | ⏳ |

---

## ⚠️ Seguridad

- Repositorio **PRIVADO** — solo colaboradores autorizados
- No compartir tokens ni URLs de webhook
- Toda comunicación en **español**
- PR requerido para mergear a `main`

---

## 📞 Contacto

- **Propietario:** Dr. Gera (gerardoromontiel-ship-it)
- **Orquestador:** Jasmin_Evergarden
- **Asesora:** Wendy_Evergarden
- **Monitoreo:** Laura_Evergarden

---

*[Sistema Multi-Agente Jasmin — Paquete de configuración para nuevos agentes]*
*[Creado por Laura_Evergarden — Agente #3]*
*[Fecha: 2026-09-21]*


